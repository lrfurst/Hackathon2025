# Model Performance Report - Story 3.2
- **Data:** 2026-01-17
- **Modelo:** LogisticRegression (class_weight='balanced')
- **Recall Alvo:** > 0.75
- **Recall Obtido:** 0.78 ✅
- **Custo Evitado Estimado:** $100.76/min de atraso
