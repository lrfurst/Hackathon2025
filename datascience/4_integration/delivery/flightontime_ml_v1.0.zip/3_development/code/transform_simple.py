
import pandas as pd
import json

def transform_simple(flight_data):
    # Lógica de extração de 5 inputs -> 7 features
    # 1. hora_do_dia | 2. dia_da_semana | 3. cia_encoded | 4. rota_encoded 
    # 5. distancia_km | 6. mes | 7. is_holiday
    pass
